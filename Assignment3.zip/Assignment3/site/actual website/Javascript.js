"use strict";
function bt1(){
    var on = document.getElementById('Naplan');
    on.src="NT_Naplan_Reading_Results_2011.png";
}
function bt2(){
    var on = document.getElementById('Naplan');
    on.src="NT_Naplan_Reading_Results_2017.png";
}
