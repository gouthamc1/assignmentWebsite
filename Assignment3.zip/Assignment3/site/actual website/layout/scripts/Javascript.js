"use strict";
function bt1(){
    var on = document.getElementById('Nutrition');
    on.src="images/demo/nut.jpg";
}
function bt2(){
    var on = document.getElementById('Nutrition');
    on.src="images/demo/8.jpg";
}
